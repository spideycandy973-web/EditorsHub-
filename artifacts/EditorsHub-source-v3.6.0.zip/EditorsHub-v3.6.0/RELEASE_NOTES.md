# EditorsHub v3.6.0 — master base, ready to customise

Package remains `com.editorshub`, application label `EditorsHub`; all code and assets are original.

## What's new in 3.6.0

- **Deleted the legacy:** unused v2 `src/components/` tree, 63 stale screenshots
  and six obsolete source archives are gone.
- **One-file customisation:** `src/theme/brand.ts` controls the app name,
  wordmark, domain, Android package, version, links and palette; `applyBrand()`
  applies the palette as CSS variables at startup. Home, Settings and About read
  every identity value from it. Change one file, then customise from there.
- **44 real effects** (up from 21). Added 23 working canvas effects: posterize,
  threshold, solarize, duotone, gradient map, levels, colour balance, emboss,
  edge detect, halftone, scanlines, glitch blocks, ripple, bulge, twirl, mirror,
  kaleidoscope, motion blur, directional blur, lens flare, starfield, bokeh and
  rain. All are distributed across the 32 Effect Browser categories, so each
  category now offers 6–12 working effects.
- The compositor's scratch canvas now requests `willReadFrequently`, removing
  all Canvas2D readback warnings.
- `docs/MASTER_CLONE.md` maps all 30 reference screens/panels to their
  implementations and explains the clean-room boundary.
- `versionCode 13`, `versionName 3.6.0`, PWA cache `editorshub-v13`.
  `npm run typecheck`, `npm run build`, `node tools/verify-gif.mjs` (7/7) and
  `node tools/smoke.mjs --shots` (**58/58**, zero console errors) all pass.

## Install

`EditorsHub-Motion.apk` (Capacitor, `com.editorshub`) is the installable build
and is attached to `apk-latest`, `v3.6.0` and `editorshub-latest`.
`EditorsHub-debug.apk` is the native Compose build; release APK/AAB are unsigned
by design (see `EditorsHub/docs/RELEASE_SIGNING.md`).
`EditorsHub-source-v3.6.0.zip` contains the complete source tree.

---

# EditorsHub v3.5.0 — reference APK reverse-engineering

Package remains `com.editorshub`, application label `EditorsHub`; all code and assets are original.

## What's new in 3.5.0

- **Reverse-engineered the actual APK you shared.** `UM Clone_8.0.1.apk`
  (294,346,248 bytes, `com.alightcreative.ultramotion`) was downloaded inside
  GitHub Actions and analysed with **REA** (JADX MCP provider: 37,206 classes,
  5,437 resources), **Ghidra 12.2 headless** (43 native functions via a Java
  GhidraScript), **JADX 1.5.6**, **APKTool 3.0.3** (1,076 colours, 1,237
  dimensions, 3,310 strings, 1,379 styles, 250 layouts) and **androguard**.
  Only compact measurements are committed in `apk-analysis/`; the APK, DEX
  bytecode and proprietary bitmaps are not.
  [docs/APK_AUDIT.md](docs/APK_AUDIT.md) has the full table.
- **Exact palette** from `resources.arsc`: `#121215` / `#1c1c1f` / `#262629` /
  `#2e2e33` / `#00ffa8`.
- **Full-screen Effect Browser** with X / "Effect Browser" / search, five quick
  picks, all **32 exact APK category names**, 3-column subcategory grids and the
  bottom **Guide card** (description, tag chips, `+ Standard Settings`, star
  favourites). Every tile applies a real working canvas effect.
- **`No presets... yet!` dialog** with the mini-editor illustration,
  `Discover Presets`, `Close`, real local preset storage (save / list / apply /
  delete) and a built-in motion-preset gallery.
- **Seven-panel bottom tab strip** in the property pane, always-visible right
  preview/zoom rail, and `Save Preset` rewired to store locally.
- `versionCode 12`, `versionName 3.5.0`, PWA cache `editorshub-v12`.
  `npm run typecheck`, `npm run build`, `node tools/verify-gif.mjs` (7/7) and
  `node tools/smoke.mjs --shots` (**52/52**, zero console errors) all pass.

## Install

`EditorsHub-Motion.apk` (Capacitor, `com.editorshub`) is the installable build
and is attached to `apk-latest`, `v3.5.0` and `editorshub-latest`.
`EditorsHub-debug.apk` is the native Compose build; release APK/AAB are unsigned
by design (see `EditorsHub/docs/RELEASE_SIGNING.md`).
`EditorsHub-source-v3.5.0.zip` contains the complete source tree.

---

# EditorsHub v3.4.0 — full reference-recording pass

Package remains `com.editorshub`, application label `EditorsHub`; all code and assets are original.

## What's new in 3.4.0

- **The entire 10:29.66 screen recording was analysed, not approximated.** The 301,626,146-byte
  Google Drive MP4 exceeds the agent workspace's 100 MiB per-file cap, so
  `.github/workflows/reference-frames.yml` fetches it inside GitHub Actions, verifies its size
  and commits only compact derived frames: **747 distinct UI states**, 38 labelled contact
  sheets, 630 one-second timeline frames and 8 timeline sheets. Every sheet was reviewed.
  [docs/VIDEO_AUDIT.md](docs/VIDEO_AUDIT.md) lists the screens, timings and sampled colours.
- **Exact palette** from the decoded pixels: `#121214` / `#1c1c1e` / `#262628` / `#dfe3ff` /
  `#01ffa7`.
- **Cold-launch splash** — black field, animated white double-arc swirl and a spinner, with a
  `prefers-reduced-motion` path.
- **Full-screen About** with the wordmark, green link and a device/build-information card that
  reports only live browser values (viewport, DPR, memory, CPU, storage estimate, user agent,
  online/standalone state).
- **Projects**: Sort by Date / Name / Duration, date-grouped rows with thumbnails, and a real
  selection mode — Select All, Fix (checks missing media), Export (ZIP of XML packages),
  Duplicate (clones stored projects), Delete with a confirmation dialog.
- **Export & Share** with the six recorded formats, all genuinely encoded: video via
  MediaRecorder, Project Package ZIP, full-resolution PNG, PNG sequence ZIP, XML, and animated
  GIF. `src/editor/gif.ts` is a hand-written GIF89a/LZW encoder with a 256-colour palette and
  NETSCAPE looping; its output was decoded with an independent GIF decoder and verified by a
  headless end-to-end download. "Also export as a Template" saves a real XML template.
- **Five-page shape picker** with 18 built-ins, 9 extras, 26 polygon/star variants and 18
  original normalized vector silhouettes drawn by `Path2D`; **Effect Browser** category tiles.
- `versionCode 11`, `versionName 3.4.0`, PWA cache `editorshub-v11`. `npm run typecheck`,
  `npm run build` and `node tools/smoke.mjs --shots` are clean: **40/40** checks, zero console
  errors/warnings.

## Install

`EditorsHub-Motion.apk` (Capacitor, `com.editorshub`) is the installable build and is attached to
`apk-latest`, `v3.4.0` and `editorshub-latest`. `EditorsHub-debug.apk` is the native Compose
build; release APK/AAB are unsigned by design (see `EditorsHub/docs/RELEASE_SIGNING.md`).
`EditorsHub-source-v3.4.0.zip` contains the complete source tree.

---

# EditorsHub v3.3.0 — reference chrome + video frame-audit tooling

Package remains `com.editorshub`, application label `EditorsHub`; all code and assets are original.

## What's new in 3.3.0

- **Device chrome matched to the reference frames.** Every 1220 × 2712 still shows the Android
  status strip (time, network, signal, Wi-Fi, battery) and the bottom gesture pill. The browser/PWA
  shell now reproduces both. `src/um/Chrome.tsx` shows only real data: the local clock, battery
  level/charging state from the Battery Status API, and signal/Wi-Fi state from Network Information
  and online/offline events. Unsupported values are omitted, never invented. On native Android the
  web chrome is hidden so the OS chrome is not drawn twice.
- **Real control, not decoration.** Settings gained a working **Device chrome** switch that
  persists with the other preferences. `prefers-reduced-motion` disables all new animations.
- **Screen and tab transitions.** Home ↔ editor and Home ↔ Projects now animate; tab panes are
  keyed so the transition replays on every switch.
- **Frame-audit pipeline.** `tools/video-frames.mjs` accepts the split recording parts, rebuilds
  the continuous 10:29.66 timeline, extracts one review frame per second plus every scene change,
  and writes a browsable `analysis/contact-sheet.html` with `manifest.json`, `scenes.json` and
  `frames.json`. Generated frames are excluded from Git.
- **Honest audit status.** The source recording is `Screenrecorder-2026-11-04-20-36-00-405.mp4`,
  301,626,146 bytes, 629,660 ms, 1220 × 2712. It exceeds the agent workspace's 100 MiB per-file
  transfer limit; Drive's unauthenticated download redirects to sign-in. See
  [docs/VIDEO_AUDIT.md](docs/VIDEO_AUDIT.md) for every route attempted and
  [docs/VIDEO_SPLIT_GUIDE.md](docs/VIDEO_SPLIT_GUIDE.md) for exact 3-part split commands.
  **No video frames have been watched**; the full pixel-by-pixel video pass begins when the parts
  arrive. This release is built from the 20 attached still references only.
- `versionCode 10`, `versionName 3.3.0`, PWA cache `editorshub-v10`. `npm run typecheck` and
  `npm run build` are clean.

## Install

`EditorsHub-Motion.apk` (Capacitor, package `com.editorshub`) is the installable web editor build;
it is attached to `apk-latest`, `v3.3.0` and `editorshub-latest` and committed at the repo root.
`EditorsHub-debug.apk` is the native Compose build; release APK/AAB are unsigned by design —
configure a keystore (see `EditorsHub/docs/RELEASE_SIGNING.md`) or run `android-release.yml` with
keystore secrets. `EditorsHub-source-v3.3.0.zip` contains the complete source tree.

---

# EditorsHub v3.2.0 — responsive, fully wired editor

A correctness and responsiveness pass over v3.1.0. Package remains `com.editorshub`, application
label `EditorsHub`; no proprietary assets are copied.

## What's new in 3.2.0

- **Every control audited and wired.** 143 headless interaction checks across the launcher,
  settings, create sheet, Add/Shape sheets, transport, timeline, tools rail, all eight property
  panes, export, project settings, overflow menu, drawing pads, elements and templates — all pass
  with zero console errors/warnings.
- **Fixed genuinely dead controls.** The timeline's root `pointerdown` handler used to call
  `setPointerCapture`, which swallowed clicks on the layer eye, clip-back chevron, keyframe diamond
  and trim handles. Those controls now work; the keyframe diamond is always visible so the first
  keyframe can be added from the clip.
- **Rail labels now match their panels.** Move & Transform's five rail buttons open Position, Size
  & scale, Skew, Rotation dial and Easing in that order (previously three were mislabelled).
  Border & Shadow's third button now opens a real Rounded corners panel instead of duplicating
  Shadow.
- **No duplicate effects or toast spam.** Adding/dragging a drop shadow creates exactly one
  effect; the easing graph notifies once on release rather than on every pointer move; the effects
  browser no longer selects the wrong effect after adding one.
- **Continuous edits no longer re-render the whole app.** Store mutations coalesce their React
  notifications into one per animation frame, take one undo snapshot per gesture, and avoid
  `setActivePropKey` churn. 30 synchronous slider events now produce **1** React notification
  (was 30), and undo still reverts the whole gesture. Non-playback compositing is capped at 24 fps.
- **Editing UI aligned closer to the reference screens.** Teal numeric readouts, a large
  "Swipe here to move layer" pad with corner marks, a five-button left rail, a magnifier/bolt
  glyph, a reference-style property-detail top bar, and 13 fresh screenshots.
- Measured under 4× CPU throttling: slider drag 60 rAF frames with **zero long tasks**; 10-layer
  playback 60 rAF frames with **zero long tasks**. `npm run typecheck` and `npm run build` clean.
- `versionCode 9`, `versionName 3.2.0`, PWA cache `editorshub-v9`.

## Install

`EditorsHub-Motion.apk` (Capacitor, package `com.editorshub`) is the installable web editor build;
it is attached to `apk-latest`, `v3.2.0` and `editorshub-latest` and committed at the repo root.
`EditorsHub-debug.apk` is the native Compose build; release APK/AAB are unsigned by design —
configure a keystore (see `EditorsHub/docs/RELEASE_SIGNING.md`) or run `android-release.yml` with
keystore secrets. `EditorsHub-source-v3.2.0.zip` contains the complete source tree.

---

# EditorsHub v3.1.0 — smooth, pixel-aligned studio

A performance and visual-correction pass over the v3.0.0 rebuild. Package remains `com.editorshub`,
application label `EditorsHub`; no proprietary assets are copied.

## What's new in 3.1.0

- **Lag removed at the source.** The compositor no longer runs a requestAnimationFrame loop while
  idle; it renders only when the project, playhead, size or media actually change. Playback renders
  at a reduced backing-store resolution and a capped preview frame rate, never overlaps two frames,
  and throttles media sync. With ten layers under 4× CPU throttling the headless browser went from
  17 fps / 44 long tasks to 38 fps / 5 long tasks; unthrottled it holds 61 fps with zero long tasks.
- **Timeline is imperative.** Playhead, timecode and the clip strip now slide with one CSS transform
  and one text node per frame instead of re-rendering the React tree. Scrubbing and playback stay
  responsive and the timecode actually advances (previously it was frozen because time changes were
  never subscribed to by the UI).
- **Startup and mutation cost.** Removed React StrictMode double-render, the unused 599-line legacy
  stylesheet, four 720×1280 JPEG encodes at boot, and redundant `structuredClone` calls on autosave.
- **Pixel alignment to the reference screens.** Bare gear + filled avatar, single-line Upload XML
  card, real icon set, filled-house / square-play bottom navigation; Settings with info icons,
  branding divider and Website/Telegram/TikTok/About rows; crop-marked ratio chips; centred 9:16
  canvas with no permanent right rail; reference back/export glyphs; seven-icon transport without a
  play disc; fixed playhead with a long tail; teal FAB that turns into a close chevron while a sheet
  is open; Add and Shape sheets without a close X; 18-shape picker silhouettes corrected.
- **Real selection handles.** On the properties screen a selected layer now shows eight draggable
  handles: dragging the box moves the layer and dragging a corner scales it, both recorded in the
  undo history. Property tiles follow the reference 3-then-4 layout (and the 4-tile camera layout),
  with a NEW badge on Presets and five real quick tools. Layers get descriptive names such as
  “Circle 1”.
- Verified with `npm run typecheck`, `npm run build`, a 27/27 headless Chromium suite (zero console
  errors/warnings), 61 fps unthrottled playback and 38 fps under 4× CPU throttling with ten layers.
- `versionCode 8`, `versionName 3.1.0`, PWA cache `editorshub-v8`. Eleven fresh screenshots in
  `docs/screenshots/*-v3.1.0.png`.

## Install

`EditorsHub-Motion.apk` (Capacitor, package `com.editorshub`) is the installable web editor build;
it is attached to `apk-latest`, `v3.1.0` and `editorshub-latest` and committed at the repo root.
`EditorsHub-debug.apk` is the native Compose build; release APK/AAB are unsigned by design —
configure a keystore (see `EditorsHub/docs/RELEASE_SIGNING.md`) or run `android-release.yml` with
keystore secrets. `EditorsHub-source-v3.1.0.zip` contains the complete source tree.

---

# EditorsHub v3.0.0 — dark studio rebuild

An original, production-structured Android motion editor: Kotlin + Jetpack Compose + Material 3,
Room, Hilt, WorkManager, Media3, OpenGL ES 2.0, MediaCodec/MediaMuxer and the Storage Access
Framework. Package `com.editorshub`, application label `EditorsHub`.

## What's new in 3.0.0

- **The UI was rebuilt to the supplied black/lavender reference screens**, not incrementally
  restyled: near-black launcher with centred wordmark, lavender Upload / Import / Create actions,
  QR package import, pill nav, segmented Projects/Templates/Elements, settings and create sheets,
  black 9:16 editor, seven-icon transport, centre playhead, striped clips, right zoom rail, teal
  FAB, 11-tile Add grid, 18-shape picker and eight railed property sheets.
- **Real interaction throughout**: 28 canvas shapes, freehand and vector drawing, camera layers,
  cubic-bezier easing, masks, 20 effects, motion presets, multi-layer clipboard, split/trim,
  undo/redo, autosave, XML/QR/ZIP package import and video/frames/still/XML export.
- **New engine capabilities**: composition-wide camera transforms, real cubic-bezier easing
  curves, audio resampling in the Web Audio export mix, low-quality preview rendering.
- Verified with `npm run typecheck`, `npm run build` and three headless Chromium E2E suites
  (46 checks, zero console errors/warnings).
- `versionCode 7`, `versionName 3.0.0`; PWA cache `editorshub-v7`.

## Install

`EditorsHub-Motion.apk` (Capacitor, package `com.editorshub`) is the installable web editor build;
it is attached to `apk-latest`, `v3.0.0` and `editorshub-latest` and committed at the repo root.
`EditorsHub-debug.apk` is the native Compose build; release APK/AAB are unsigned by design —
configure a keystore (see `EditorsHub/docs/RELEASE_SIGNING.md`) or run `android-release.yml` with
keystore secrets. `EditorsHub-source-v3.0.0.zip` contains the complete source tree.

## Previous releases

## What's new in 2.4.0 — fixes, APK release and closer proportions

- **The installable Capacitor APK is now published on GitHub**: `EditorsHub-Motion.apk` is attached
  to `apk-latest`, to this versioned release and to the rolling `editorshub-latest` release, and is
  committed at the repository root. Its package was unified to **`com.editorshub`** (the native
  project and the web wrapper now use the same application id), as required.
- **The APK is verified before release**: a new Android 33 emulator smoke test installs and launches
  `EditorsHub-Motion.apk` itself (not just the native debug build), then checks the process is alive
  and that logcat contains no `FATAL EXCEPTION`.
- **Fixed timeline scrolling**: manually scrolling the timeline used to leave the centre-anchored
  playhead off-screen and the time unchanged. Scrolling now scrubs the composition in real time and
  the playhead stays exactly at the centre (verified in headless Chromium).
- **Composition preview enlarged**: the default new project is 4:5 (matching Alight Motion's
  getting-started canvas); the timeline and inspector were compacted so the preview fills roughly
  three quarters of the screen width instead of one third.
- Verified real workflows end-to-end: clip move/trim, split, duplicate, undo/redo, XML export
  download, XML import validation, still-frame export download, project save/open, effects,
  keyframes and 134 inspector buttons with zero console errors.
- `versionCode 6`, `versionName 2.4.0`; PWA cache `editorshub-v6`.

## Previous release — 2.3.0 (pixel-level Alight Motion geometry)

The editor's layout and interaction model now follow the Alight Motion screenshots closely, while
keeping **EditorsHub**'s own name, logo and original code. No proprietary assets are copied.

- **Seven transport icons spread across the full width** of a 38 px control bar; separators removed.
- **Contextual navigation bar**: with a property panel open it becomes back / panel name / overflow
  (`Move & Transform`, `Effects`, `Keyframes`, `Project`); otherwise project name / gear / export.
- **Panel replaces the bottom tab bar**: the inspector fills the bottom of the screen with AM's
  `▼ property` dropdown, a left rail (back / keyframes / fit / layers) and a labelled right rail
  ending in the big **X**. Closing the panel reveals the icon-only tab bar again.
- **Add menu rebuilt** to AM's six categories (Shape, Media, Audio, Object, Element, Freehand
  Drawing) with a teal selected-icon box, an **All / Browse** filter rail, a two-column built-in
  thumbnail grid and a right rail of **All / Vector Drawing / Text / X** with text labels.
- **Real freehand drawing**: a pointer-driven canvas with brush colour, size, undo and clear; the
  result is rasterised to a PNG and added as a genuine image layer. No simulated features.
- **Property sheet header** (`▼ Move & Transform`) with a working panel-switch dropdown; top bar
  overflow opens the real Layer options dialog.
- **AM-style timeline**: flat orange / teal / blue clip bars with dark labels, a hamburger on every
  clip, a grey `‹` selected-layer arrow attached to the bar, real asset thumbnails in the layer
  gutter, a faint `EditorsHub` ruler watermark, and short ruler ticks. The floating layer chip was
  removed because AM attaches that control to the clip.
- Lighter AM navigation-bar navy (`#2b3046`), panel navy (`#22263a`), rail navy (`#191d2b`).
- Launcher gained the classic AM **Welcome** card with three outlined pill buttons and a tutorial
  card; all buttons perform real actions (help, templates, XML import).
- Mobile grid locked to the viewport so wide property controls can no longer push the UI off-screen.
- `versionCode 5`, `versionName 2.3.0`; PWA cache `editorshub-v5`.

## Previous release — 2.2.0 (closer Alight Motion fidelity)

This release tightens the editor to Alight Motion's actual layout and interaction model while
keeping **EditorsHub**'s own name, logo and original code. No proprietary assets are copied.

- **Clean preview**: floating zoom chip, resolution/FPS badges, layer chip and zoom toolbar were
  removed from the canvas. The composition now starts light grey, with a subtle vertical
  `EditorsHub` watermark at the right edge, exactly as Alight Motion's empty project does. Those
  controls are still real and reachable from Settings (zoom slider, grid/guides) and the Add menu.
- **Navigation bar**: back / project name / settings gear / export, single-line title on phones.
- **Single-row transport**: undo, redo, start, play/pause, end, duplicate, fit — no second ruler row.
- **Centre-anchored playhead**: the playhead is fixed at the horizontal centre of the timeline and
  layers scroll underneath it. Scrubbing uses drag-delta so it stays stable while the ruler moves;
  playback, scrubbing and zoom were verified to keep the playhead at the exact centre.
- **AM-style ruler**: small tick marks only, plain white `mm:ss:ff` timecode above the playhead,
  no numeric labels on phones. The layer chip with previous/next arrows sits above the clip bars.
- **Layer gutter**: eye + thumbnail pinned at the left edge; amber/teal/blue clip bars; no
  timeline toolbar on phones (all its actions live in the real Layer options dialog).
- **Circular outlined Add Layer button** at the bottom-right of the timeline, replaced by the big
  **X** in the inspector rail while the Add menu is open.
- **Two rails, not four**: one panel rail on the left, one persistent quick-action rail on the
  right (All / Text / Shapes / close). Every button performs a real action.
- All template circles now carry Alight Motion's thin teal ring.
- `versionCode 4`, `versionName 2.2.0`; PWA cache `editorshub-v4`.

## Previous release — 2.1.0 (Alight-Motion-style UI)

This release rebuilds the visible interface around Alight Motion's layout and interaction model,
while keeping **EditorsHub**'s own name, logo and original code. No proprietary assets are copied.

### Light "Projects" launcher (web/PWA + home)
- Hamburger menu, centred wordmark, avatar; "Explore Templates" circular carousel;
  "Latest projects" with a dashed **Create New Project** card and project cards showing duration,
  ratio, resolution and layer count; "Get started" cards; bottom navigation with the signature
  **teal circular +** button.
- Projects tab with "Upload an XML file from your device", filter chips and a saved-project list.
- Templates tab opens real editable demo projects; Tutorials tab wires to real editor actions.
- AM-style **Create Project** sheet: name, six aspect ratios, 480p–4K, 24/25/30/50/60 fps,
  duration, background colour and an editable demo-composition option.

### Dark midnight editor
- Navigation bar: back, project name/resolution/fps, guides, overflow menu, export.
- Control bar: undo, redo, skip-to-start, play, skip-to-end, duplicate, fit — plus a tick ruler
  and a centred `00:00:00` timecode pill, matching Alight Motion's control bar.
- Preview with a watermark pill, circular fit button, checkerboard/guides and zoom controls.
- Timeline with an eye/lock/thumbnail layer column, **amber text, teal shape, blue media,
  purple audio, coral solid** clip bars, a white playhead and diamond keyframe markers.
- Teal rounded-square **Add Layer FAB** anchored to the timeline, plus a bottom tool dock and a
  vertical tool rail in the inspector.
- **Add menu** rebuilt as Alight Motion's category row (Shape / Media / Audio / Object / Element /
  Text) with a right-hand quick-action rail and real layer/import actions behind every item.
- Inspector panels restyled as AM-style property rows with teal sliders, numeric value boxes and
  per-property keyframe diamonds.
- New mint/teal accent (`#10E0A0`) on midnight navy (`#141824`) throughout both the web editor
  and the native Compose app; launcher icon, splash, notification icon and PWA icons recoloured to
  the same palette.

### Native Android app
- `EditorPalette` reskinned to midnight navy + teal; top bar, control bar, timeline clip colours,
  playhead, inspector tabs and the new Add Layer FAB all match the web editor.
- Home hero restyled as "What will you create?" with a teal Create New Project button.
- All existing destinations and features remain real and functional; no fake controls added.

## What works (unchanged functionality)
- **Workspace**: real multilayer compositor, hardware Canvas + OpenGL ES shader chain, playback,
  frame stepping, zoom/fit/fullscreen, transparency checkerboard and safe-area/grid/centre guides.
- **Timeline**: drag/trim/split/duplicate/reorder, multi-select, group/ungroup, lock/hide/mute,
  magnetic + frame snapping, zoom-to-fit/selection, undo/redo.
- **Animation**: Bezier/linear/ease/hold/elastic/bounce keyframes, draggable curve editor, custom
  control points, colour tracks, copy/paste, motion presets.
- **Effects**: 18 stackable animatable effects; Effects Library with live rendered previews;
  validated node-based custom effect builder (DAG → real render stack).
- **Text / shapes / vectors / masks**: gradients, strokes, shadows, editable paths, multiple masks
  with feather/expand/invert and keyframes.
- **Transitions / audio**: 9 transition types, crossfades, PCM waveforms, volume/fades, AAC mixing.
- **Import**: streaming native JSON, Alight Motion XML, Node Video ZIP, After Effects AEPX, AEP
  reference preservation; no size cap; conversion reports; media relinking; cancellation.
- **Export**: MediaCodec H.264/H.265 → MP4, exact rational frame rates, 480p–4K, bitrate/quality,
  AAC, MediaStore or app storage, real progress and cancellation, output validation.
- **Projects**: versioned JSON in Room, autosave, recovery, thumbnails, share, export, version
  history, search/sort/grid-list, full creation settings (144p–4K, 8 ratios, 13 frame rates,
  background, colour space, timebase, audio sample rate).
- **AI Studio**: real OpenAI-compatible inference with Android Keystore-encrypted key storage;
  generation is disabled (never simulated) when the service is unavailable.
- **UI**: directional navigation/tab transitions, animated selection indicators and inspector
  panels, six implemented destinations, UI scaling and language switching.

## Stability (carried from 2.0.1)
- The cold-start AppCompat theme crash is fixed, and CI runs an **Android 33 emulator launch
  smoke test** that fails on process death or `FATAL EXCEPTION` in logcat.
- Runtime guards for Hilt/WorkManager init order, DataStore corruption, project load, autosave,
  import, export, GL/EGL/shader failures, OOM and invalid composition sizes.

## Honest limitations
Binary `.aep`, AE expressions/3D/plugins, zero-copy SurfaceTexture decoding, optical flow,
video-reference AI analysis, AV1/MOV/WebM/image-sequence output and 120 fps hardware encoding are
not implemented and are not exposed as working features. Full details:
`EditorsHub/docs/ARCHITECTURE.md`.

MIT licensed. No proprietary source, branding or assets from Alight Motion.
